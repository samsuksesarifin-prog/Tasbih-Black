TASBIH HITAM - cara build
1. Buka Android Studio > File > Open > pilih folder TasbihHitam ini.
2. Tunggu Gradle sync selesai (butuh internet pertama kali).
3. Colok HP (aktifkan Developer options > USB debugging) lalu klik Run,
   atau Build > Build APK(s) untuk file APK.

Cara pakai:
- Tap di mana saja = +1
- Tahan lama di layar = kunci / buka kunci (anti tap tidak sengaja di saku)
- Tombol volume atas/bawah = +1 (saat aplikasi di depan)
- "Target" di kiri atas: ganti 33 / 99 / 100 / tanpa target (getar panjang saat tercapai)
- "Reset" di bawah: ulang ke 0
