package com.example.tasbihhitam

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

data class Counter(
    val id: Long,
    var name: String,
    var target: Int,   // 0 = tanpa target (mode bebas)
    var lap: Int,      // 0 = tanpa getar putaran
    val hist: MutableMap<String, Int> = mutableMapOf()
)

fun fmt(c: Calendar): String = String.format(
    Locale.US, "%04d-%02d-%02d",
    c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)
)

fun todayKey(): String = fmt(Calendar.getInstance())

object Store {
    private const val PREF = "tasbih_v2"

    fun load(ctx: Context): MutableList<Counter> {
        val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("data", null)
        val list = mutableListOf<Counter>()
        if (s != null) {
            try {
                val arr = JSONArray(s)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val h = mutableMapOf<String, Int>()
                    val ho = o.optJSONObject("hist")
                    if (ho != null) {
                        val keys = ho.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            h[k] = ho.getInt(k)
                        }
                    }
                    list.add(Counter(o.getLong("id"), o.getString("name"), o.getInt("target"), o.getInt("lap"), h))
                }
            } catch (e: Exception) {
                list.clear()
            }
        }
        if (list.isEmpty()) list.add(Counter(System.currentTimeMillis(), "Bebas", 0, 33))
        return list
    }

    fun save(ctx: Context, list: List<Counter>) {
        val arr = JSONArray()
        for (c in list) {
            val o = JSONObject()
            o.put("id", c.id)
            o.put("name", c.name)
            o.put("target", c.target)
            o.put("lap", c.lap)
            val h = JSONObject()
            for ((k, v) in c.hist) h.put(k, v)
            o.put("hist", h)
            arr.put(o)
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("data", arr.toString()).apply()
    }
}
