package com.example.tasbihhitam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

class BarView(ctx: Context) : View(ctx) {
    var fraction = 0f
        set(v) { field = v; invalidate() }
    var fillColor = Color.BLUE
    var trackColor = Color.LTGRAY
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        val w = width.toFloat()
        val r = h / 2f
        p.style = Paint.Style.FILL
        p.color = trackColor
        c.drawRoundRect(0f, 0f, w, h, r, r, p)
        if (fraction > 0f) {
            p.color = fillColor
            c.drawRoundRect(0f, 0f, w * fraction.coerceIn(0f, 1f), h, r, r, p)
        }
    }
}

class BarChartView(ctx: Context) : View(ctx) {
    var values: List<Int> = emptyList()
    var labels: List<String> = emptyList()
    var target = 0
    var accent = Color.BLUE
    var muted = Color.GRAY
    var textColor = Color.BLACK
    var lineColor = Color.GRAY
    var selected = -1
    var onSelect: ((Int) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun d(v: Float) = v * resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val n = values.size
        if (n == 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val labelH = d(20f)
        val topPad = d(16f)
        val chartH = h - labelH - topPad
        val bottom = topPad + chartH
        val maxV = maxOf(values.maxOrNull() ?: 0, target, 1) * 1.15f
        val slot = w / n
        val barW = slot * 0.62f
        p.textAlign = Paint.Align.CENTER
        p.textSize = d(10f)

        if (target > 0) {
            val y = topPad + chartH * (1f - target / maxV)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1f)
            p.color = lineColor
            p.pathEffect = DashPathEffect(floatArrayOf(d(4f), d(4f)), 0f)
            c.drawLine(0f, y, w, y, p)
            p.pathEffect = null
        }

        for (i in 0 until n) {
            val v = values[i]
            val left = i * slot + (slot - barW) / 2f
            val top = bottom - chartH * v / maxV
            if (v > 0) {
                p.style = Paint.Style.FILL
                p.color = if (target <= 0 || v >= target) accent else muted
                c.drawRoundRect(left, top, left + barW, bottom, d(3f), d(3f), p)
                if (n <= 7) {
                    p.color = textColor
                    c.drawText(v.toString(), left + barW / 2f, top - d(3f), p)
                }
            }
            if (i == selected) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = d(1.5f)
                p.color = textColor
                c.drawRoundRect(left - d(2f), topPad, left + barW + d(2f), bottom, d(3f), d(3f), p)
            }
            val lb = labels.getOrNull(i) ?: ""
            if (lb.isNotEmpty()) {
                p.style = Paint.Style.FILL
                p.color = if (i == selected) textColor else lineColor
                c.drawText(lb, i * slot + slot / 2f, h - d(4f), p)
            }
        }

        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1f)
        p.color = lineColor
        c.drawLine(0f, bottom, w, bottom, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) {
            parent?.requestDisallowInterceptTouchEvent(true)
            val n = values.size
            if (n == 0) return true
            val i = (e.x / (width.toFloat() / n)).toInt().coerceIn(0, n - 1)
            if (i != selected) {
                selected = i
                invalidate()
                onSelect?.invoke(i)
            }
        }
        return true
    }
}
