package com.example.tasbihhitam

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var vibrator: Vibrator
    private lateinit var countText: TextView
    private lateinit var targetText: TextView
    private lateinit var lockText: TextView
    private lateinit var resetText: TextView

    private var count = 0
    private var target = 33          // 0 = tanpa target
    private var locked = false
    private var lastTap = 0L

    private val targets = intArrayOf(33, 99, 100, 0)
    private val minTapGapMs = 120L   // jeda minimal antar tap (anti tap ganda)

    private val dim = Color.rgb(70, 70, 70)       // abu gelap, hemat & tidak silau
    private val dimmer = Color.rgb(40, 40, 40)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Tampil di atas layar kunci & jaga layar tetap menyala
        setShowWhenLocked(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefs = getSharedPreferences("tasbih", MODE_PRIVATE)
        count = prefs.getInt("count", 0)
        target = prefs.getInt("target", 33)

        vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        buildUi()
        render()
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        countText = TextView(this).apply {
            textSize = 96f
            setTextColor(dim)
            gravity = Gravity.CENTER
        }
        root.addView(countText, FrameLayout.LayoutParams(-1, -1))

        targetText = smallLabel(Gravity.TOP or Gravity.START).also { root.addView(it) }
        lockText = smallLabel(Gravity.TOP or Gravity.END).also { root.addView(it) }
        resetText = smallLabel(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { root.addView(it) }

        targetText.setOnClickListener { if (!locked) cycleTarget() }
        resetText.setOnClickListener { if (!locked) confirmReset() }

        // Tap di mana saja = +1, tekan lama = kunci/buka kunci
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { increment(); return true }
            override fun onLongPress(e: MotionEvent) { toggleLock() }
        })
        // Tombol kecil menangani kliknya sendiri; sisanya diteruskan ke detector
        root.setOnTouchListener { _, ev -> detector.onTouchEvent(ev); true }

        setContentView(root)
        setBrightness(0.01f) // kecerahan minimum -> tampak seperti mati
    }

    private fun smallLabel(g: Int) = TextView(this).apply {
        textSize = 14f
        setTextColor(dimmer)
        setPadding(48, 96, 48, 96)
        layoutParams = FrameLayout.LayoutParams(-2, -2, g)
    }

    private fun setBrightness(v: Float) {
        val lp = window.attributes
        lp.screenBrightness = v
        window.attributes = lp
    }

    private fun increment() {
        if (locked) return
        val now = System.currentTimeMillis()
        if (now - lastTap < minTapGapMs) return
        lastTap = now

        count++
        prefs.edit().putInt("count", count).apply()
        render()

        if (target > 0 && count % target == 0) buzz(longArrayOf(0, 200, 100, 200))
        else buzz(longArrayOf(0, 25))
    }

    private fun toggleLock() {
        locked = !locked
        buzz(longArrayOf(0, 80, 60, 80))
        render()
    }

    private fun cycleTarget() {
        val i = targets.indexOf(target)
        target = targets[(i + 1) % targets.size]
        prefs.edit().putInt("target", target).apply()
        render()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setMessage("Reset hitungan ke 0?")
            .setPositiveButton("Reset") { _, _ ->
                count = 0
                prefs.edit().putInt("count", 0).apply()
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun render() {
        countText.text = count.toString()
        countText.setTextColor(if (locked) dimmer else dim)
        targetText.text = if (target > 0) "Target $target" else "Tanpa target"
        lockText.text = if (locked) "TERKUNCI (tahan lama untuk buka)" else "tahan lama = kunci"
        resetText.text = "Reset"
    }

    private fun buzz(pattern: LongArray) {
        if (!vibrator.hasVibrator()) return
        vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
    }

    // Cadangan: tombol volume juga menambah hitungan (saat aplikasi di depan)
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.repeatCount == 0) increment()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) return true
        return super.onKeyUp(keyCode, event)
    }
}
