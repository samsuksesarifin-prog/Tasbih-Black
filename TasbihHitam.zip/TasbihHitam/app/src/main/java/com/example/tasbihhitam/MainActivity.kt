package com.example.tasbihhitam

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.InputFilter
import android.text.InputType
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar

class MainActivity : Activity() {

    private lateinit var counters: MutableList<Counter>
    private lateinit var vibrator: Vibrator

    private var cBg = 0
    private var cCard = 0
    private var cText = 0
    private var cSub = 0
    private var cMuted = 0
    private var cBorder = 0
    private var cAccent = 0
    private var origStatus = 0
    private var origNav = 0

    private var screen = 0            // 0 daftar, 1 hitung, 2 grafik, 3 atur
    private var current: Counter? = null
    private var locked = false
    private var inDark = false
    private var lastTap = 0L
    private val minTapGapMs = 120L
    private var onBack: () -> Unit = { finish() }

    private lateinit var countView: TextView
    private lateinit var progressText: TextView
    private lateinit var lapText: TextView
    private lateinit var lockBtn: TextView
    private lateinit var barView: BarView
    private lateinit var darkCount: TextView

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val dayNames = arrayOf("Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab")
    private val monthNames = arrayOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        if (night) {
            cBg = Color.parseColor("#121212"); cCard = Color.parseColor("#1C1C1C")
            cText = Color.parseColor("#EDEDED"); cSub = Color.parseColor("#A0A0A0")
            cMuted = Color.parseColor("#6B6B6B"); cBorder = Color.parseColor("#3A3A3A")
            cAccent = Color.parseColor("#4C8DFF")
        } else {
            cBg = Color.parseColor("#FAFAF8"); cCard = Color.parseColor("#FFFFFF")
            cText = Color.parseColor("#1F1F1F"); cSub = Color.parseColor("#666666")
            cMuted = Color.parseColor("#9A9A9A"); cBorder = Color.parseColor("#DDDDDD")
            cAccent = Color.parseColor("#1F6FEB")
        }
        origStatus = window.statusBarColor
        origNav = window.navigationBarColor

        vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        counters = Store.load(this)
        showList()
    }

    // ---------- helper tampilan ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun shape(fill: Int, stroke: Int, radius: Int, dashed: Boolean = false) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) {
            if (dashed) setStroke(dp(1), stroke, dp(5).toFloat(), dp(4).toFloat()) else setStroke(dp(1), stroke)
        }
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        if (primary) {
            setTextColor(Color.WHITE)
            background = shape(cAccent, 0, 10)
            setTypeface(typeface, Typeface.BOLD)
        } else {
            setTextColor(cText)
            background = shape(Color.TRANSPARENT, cBorder, 10)
        }
        setOnClickListener { onClick() }
    }

    private fun page() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(cBg)
        setPadding(dp(16), dp(16), dp(16), dp(16))
    }

    private fun header(title: String, left: String?, onLeft: (() -> Unit)?, right: String?, onRight: (() -> Unit)?): LinearLayout {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val l = label(left ?: "", 15f, cAccent)
        l.setPadding(0, dp(8), dp(12), dp(8))
        if (onLeft != null) l.setOnClickListener { onLeft() }
        val t = label(title, 17f, cText, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val r = label(right ?: "", 15f, cAccent)
        r.setPadding(dp(12), dp(8), 0, dp(8))
        if (onRight != null) r.setOnClickListener { onRight() }
        h.addView(l, lp(WRAP, WRAP))
        h.addView(t, lp(0, WRAP, 1f))
        h.addView(r, lp(WRAP, WRAP))
        return h
    }

    private fun setBrightness(v: Float) {
        val a = window.attributes
        a.screenBrightness = v
        window.attributes = a
    }

    private fun restoreBars() {
        window.statusBarColor = origStatus
        window.navigationBarColor = origNav
    }

    private fun buzz(pattern: LongArray) {
        if (!vibrator.hasVibrator()) return
        vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
    }

    // ---------- 1. daftar hitungan ----------

    private fun showList() {
        screen = 0
        current = null
        locked = false
        inDark = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setBrightness(WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE)
        restoreBars()
        onBack = { finish() }

        val root = page()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(label("Hitungan", 24f, cText, true), lp(0, WRAP, 1f))
        head.addView(button("+ Baru", false) { showEdit(null) }, lp(WRAP, WRAP))
        root.addView(head, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val today = todayKey()
        for (c in counters) {
            val n = c.hist[today] ?: 0
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(14), dp(14), dp(14))
                background = shape(cCard, cBorder, 12)
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(label(c.name, 16f, cText, true), lp(0, WRAP, 1f))
            row.addView(label(if (c.target > 0) "$n / ${c.target}" else "$n", 14f, cSub), lp(WRAP, WRAP))
            card.addView(row)
            if (c.target > 0) {
                val b = BarView(this)
                b.fillColor = cAccent
                b.trackColor = cBorder
                b.fraction = minOf(1f, n.toFloat() / c.target)
                card.addView(b, lp(MATCH, dp(5), 0f, 0, 10, 0, 0))
            } else {
                card.addView(label("Tanpa target", 12f, cMuted), lp(WRAP, WRAP, 0f, 0, 4, 0, 0))
            }
            card.setOnClickListener { locked = false; showCounter(c) }
            card.setOnLongClickListener { showMenu(c); true }
            list.addView(card, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        }
        val sv = ScrollView(this)
        sv.addView(list)
        root.addView(sv, lp(MATCH, 0, 1f))
        val hint = label("Ketuk untuk menghitung · tahan lama untuk ubah atau hapus", 12f, cMuted)
        hint.gravity = Gravity.CENTER
        root.addView(hint, lp(MATCH, WRAP, 0f, 0, 8, 0, 0))
        setContentView(root)
    }

    private fun showMenu(c: Counter) {
        AlertDialog.Builder(this)
            .setTitle(c.name)
            .setItems(arrayOf("Ubah", "Hapus")) { _, which ->
                if (which == 0) showEdit(c) else confirmDelete(c)
            }
            .show()
    }

    private fun confirmDelete(c: Counter) {
        AlertDialog.Builder(this)
            .setMessage("Hapus \"${c.name}\" beserta riwayatnya?")
            .setPositiveButton("Hapus") { _, _ ->
                counters.remove(c)
                if (counters.isEmpty()) counters.add(Counter(System.currentTimeMillis(), "Bebas", 0, 33))
                Store.save(this, counters)
                showList()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- 4. atur hitungan ----------

    private fun showEdit(c: Counter?) {
        screen = 3
        onBack = { showList() }
        val root = page()
        root.addView(header(if (c == null) "Hitungan baru" else "Ubah hitungan", "‹ Batal", { showList() }, null, null))

        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun field(e: EditText) {
            e.setTextColor(cText)
            e.setHintTextColor(cMuted)
            e.background = shape(cCard, cBorder, 10)
            e.setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        form.addView(label("Nama", 13f, cSub), lp(WRAP, WRAP, 0f, 0, 16, 0, 4))
        val nameEt = EditText(this)
        nameEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        nameEt.hint = "Contoh: Istighfar"
        nameEt.setText(c?.name ?: "")
        field(nameEt)
        form.addView(nameEt, lp(MATCH, WRAP))

        form.addView(label("Target harian", 13f, cSub), lp(WRAP, WRAP, 0f, 0, 16, 0, 4))
        val targetEt = EditText(this)
        targetEt.inputType = InputType.TYPE_CLASS_NUMBER
        targetEt.filters = arrayOf(InputFilter.LengthFilter(6))
        targetEt.hint = "Kosongkan untuk tanpa target"
        if (c != null && c.target > 0) targetEt.setText(c.target.toString())
        field(targetEt)
        form.addView(targetEt, lp(MATCH, WRAP))

        form.addView(label("Getar tiap putaran", 13f, cSub), lp(WRAP, WRAP, 0f, 0, 16, 0, 4))
        var lap = c?.lap ?: 33
        val opts = listOf(33 to "33", 99 to "99", 100 to "100", 0 to "Tanpa")
        val chips = mutableListOf<TextView>()
        fun paint() {
            for (i in chips.indices) {
                val sel = opts[i].first == lap
                chips[i].background = shape(if (sel) cAccent else Color.TRANSPARENT, if (sel) cAccent else cBorder, 10)
                chips[i].setTextColor(if (sel) Color.WHITE else cText)
            }
        }
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, o) in opts.withIndex()) {
            val t = TextView(this)
            t.text = o.second
            t.textSize = 14f
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(12), 0, dp(12))
            t.setOnClickListener { lap = o.first; paint() }
            chips.add(t)
            chipRow.addView(t, lp(0, WRAP, 1f, if (i == 0) 0 else 4, 0, if (i == opts.size - 1) 0 else 4, 0))
        }
        paint()
        form.addView(chipRow, lp(MATCH, WRAP))

        form.addView(button("Simpan", true) {
            val nm = nameEt.text.toString().trim()
            if (nm.isEmpty()) {
                nameEt.error = "Isi nama dulu"
                return@button
            }
            val tg = targetEt.text.toString().trim().toIntOrNull() ?: 0
            if (c == null) {
                counters.add(Counter(System.currentTimeMillis(), nm, tg, lap))
            } else {
                c.name = nm
                c.target = tg
                c.lap = lap
            }
            Store.save(this, counters)
            showList()
        }, lp(MATCH, WRAP, 0f, 0, 24, 0, 0))

        val sv = ScrollView(this)
        sv.addView(form)
        root.addView(sv, lp(MATCH, 0, 1f))
        setContentView(root)
    }

    // ---------- 2. layar hitung ----------

    private fun showCounter(c: Counter) {
        screen = 1
        current = c
        inDark = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setBrightness(WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE)
        restoreBars()
        onBack = { showList() }

        val root = page()
        root.addView(header(c.name, "‹ Daftar", { showList() }, "Grafik", { showChart(c) }))

        progressText = label("", 13f, cSub)
        root.addView(progressText, lp(WRAP, WRAP, 0f, 0, 12, 0, 4))
        barView = BarView(this)
        barView.fillColor = cAccent
        barView.trackColor = cBorder
        root.addView(barView, lp(MATCH, dp(5), 0f, 0, 0, 0, 12))

        val area = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = shape(Color.TRANSPARENT, cBorder, 14, true)
            isClickable = true
            setOnClickListener { increment() }
        }
        countView = label("0", 64f, cText, true)
        countView.gravity = Gravity.CENTER
        lapText = label("", 13f, cSub)
        lapText.gravity = Gravity.CENTER
        area.addView(countView, lp(WRAP, WRAP))
        area.addView(lapText, lp(WRAP, WRAP))
        area.addView(label("Ketuk di sini = +1", 12f, cMuted), lp(WRAP, WRAP, 0f, 0, 10, 0, 0))
        root.addView(area, lp(MATCH, 0, 1f, 0, 0, 0, 12))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lockBtn = button("Kunci", false) { toggleLock() }
        row.addView(lockBtn, lp(0, WRAP, 1f, 0, 0, 6, 0))
        row.addView(button("Reset", false) { confirmReset() }, lp(0, WRAP, 1f, 6, 0, 0, 0))
        root.addView(row, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        root.addView(button("Mulai gelap", true) { enterDark() }, lp(MATCH, WRAP))

        setContentView(root)
        renderCounter()
    }

    private fun renderCounter() {
        val c = current ?: return
        val n = c.hist[todayKey()] ?: 0
        countView.text = n.toString()
        countView.setTextColor(if (locked) cMuted else cText)
        if (c.target > 0) {
            progressText.text = "$n / ${c.target} hari ini"
            barView.visibility = View.VISIBLE
            barView.fraction = minOf(1f, n.toFloat() / c.target)
        } else {
            progressText.text = "Hari ini: $n  ·  tanpa target"
            barView.visibility = View.INVISIBLE
        }
        lapText.text = if (c.lap > 0) "${n % c.lap} / ${c.lap}  ·  ${n / c.lap} putaran selesai" else ""
        lockBtn.text = if (locked) "Buka kunci" else "Kunci"
    }

    private fun increment() {
        val c = current ?: return
        if (locked) return
        val now = System.currentTimeMillis()
        if (now - lastTap < minTapGapMs) return
        lastTap = now

        val key = todayKey()
        val n = (c.hist[key] ?: 0) + 1
        c.hist[key] = n
        Store.save(this, counters)

        val reached = c.target > 0 && n == c.target
        val lapHit = c.lap > 0 && n % c.lap == 0
        when {
            reached -> buzz(longArrayOf(0, 400, 150, 400, 150, 400))
            lapHit -> buzz(longArrayOf(0, 200, 100, 200))
            else -> buzz(longArrayOf(0, 25))
        }
        if (inDark) renderDark() else renderCounter()
    }

    private fun toggleLock() {
        locked = !locked
        buzz(longArrayOf(0, 80, 60, 80))
        if (inDark) renderDark() else renderCounter()
    }

    private fun confirmReset() {
        val c = current ?: return
        AlertDialog.Builder(this)
            .setMessage("Reset hitungan hari ini ke 0?")
            .setPositiveButton("Reset") { _, _ ->
                c.hist.remove(todayKey())
                Store.save(this, counters)
                renderCounter()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- mode gelap ----------

    private fun enterDark() {
        if (current == null) return
        inDark = true
        setBrightness(0.01f)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        darkCount = TextView(this)
        darkCount.textSize = 96f
        darkCount.gravity = Gravity.CENTER
        root.addView(darkCount, FrameLayout.LayoutParams(MATCH, MATCH))

        val det = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { increment(); return true }
            override fun onLongPress(e: MotionEvent) { toggleLock() }
        })
        root.setOnTouchListener { _, ev -> det.onTouchEvent(ev); true }

        onBack = { exitDark() }
        setContentView(root)
        renderDark()
    }

    private fun renderDark() {
        val c = current ?: return
        darkCount.text = (c.hist[todayKey()] ?: 0).toString()
        darkCount.setTextColor(if (locked) Color.parseColor("#222222") else Color.parseColor("#3A3A3A"))
    }

    private fun exitDark() {
        val c = current
        inDark = false
        if (c != null) showCounter(c) else showList()
    }

    // ---------- 3. grafik harian ----------

    private fun showChart(c: Counter) {
        screen = 2
        onBack = { showCounter(c) }
        val root = page()
        root.addView(header(c.name, "‹ Kembali", { showCounter(c) }, null, null))

        val chart = BarChartView(this)
        chart.accent = cAccent
        chart.muted = cMuted
        chart.textColor = cText
        chart.lineColor = cSub
        chart.target = c.target
        val info = label("Ketuk batang untuk melihat angkanya", 13f, cSub)

        var days = 7
        var vals = listOf<Int>()
        var dates = listOf<String>()

        fun stat(title: String): Pair<View, TextView> {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(10), dp(10), dp(10), dp(10))
            box.background = shape(cCard, cBorder, 10)
            box.addView(label(title, 11f, cSub))
            val v = label("", 15f, cText, true)
            box.addView(v)
            return Pair(box, v)
        }
        val st1 = stat(if (c.target > 0) "Tercapai" else "Hari aktif")
        val st2 = stat("Rata-rata")
        val st3 = stat("Total")

        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        val b7 = TextView(this)
        val b30 = TextView(this)
        fun segPaint() {
            for ((t, d) in listOf(b7 to 7, b30 to 30)) {
                val sel = days == d
                t.background = shape(if (sel) cAccent else Color.TRANSPARENT, if (sel) cAccent else cBorder, 10)
                t.setTextColor(if (sel) Color.WHITE else cText)
            }
        }

        fun load() {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -(days - 1))
            val v = mutableListOf<Int>()
            val lb = mutableListOf<String>()
            val dt = mutableListOf<String>()
            for (i in 0 until days) {
                val dow = dayNames[cal.get(Calendar.DAY_OF_WEEK) - 1]
                val dom = cal.get(Calendar.DAY_OF_MONTH)
                v.add(c.hist[fmt(cal)] ?: 0)
                lb.add(if (days <= 7) dow else if (i % 5 == 0 || i == days - 1) dom.toString() else "")
                dt.add("$dow, $dom ${monthNames[cal.get(Calendar.MONTH)]}")
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            vals = v
            dates = dt
            chart.values = v
            chart.labels = lb
            chart.selected = -1
            chart.invalidate()
            info.text = "Ketuk batang untuk melihat angkanya"
            val total = v.sum()
            val ok = if (c.target > 0) v.count { it >= c.target } else v.count { it > 0 }
            st1.second.text = "$ok / $days hari"
            st2.second.text = (total / days).toString()
            st3.second.text = total.toString()
            segPaint()
        }

        for ((t, txt) in listOf(b7 to "7 hari", b30 to "30 hari")) {
            t.text = txt
            t.textSize = 13f
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(10), 0, dp(10))
        }
        b7.setOnClickListener { days = 7; load() }
        b30.setOnClickListener { days = 30; load() }
        seg.addView(b7, lp(0, WRAP, 1f, 0, 0, 4, 0))
        seg.addView(b30, lp(0, WRAP, 1f, 4, 0, 0, 0))
        root.addView(seg, lp(MATCH, WRAP, 0f, 0, 16, 0, 12))

        chart.onSelect = { i -> info.text = "${dates[i]}: ${vals[i]}" }
        root.addView(chart, lp(MATCH, dp(220)))
        root.addView(info, lp(MATCH, WRAP, 0f, 0, 10, 0, 12))

        val stats = LinearLayout(this)
        stats.orientation = LinearLayout.HORIZONTAL
        stats.addView(st1.first, lp(0, WRAP, 1f, 0, 0, 4, 0))
        stats.addView(st2.first, lp(0, WRAP, 1f, 4, 0, 4, 0))
        stats.addView(st3.first, lp(0, WRAP, 1f, 4, 0, 0, 0))
        root.addView(stats, lp(MATCH, WRAP))

        setContentView(root)
        load()
    }

    // ---------- tombol fisik ----------

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        onBack()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (screen == 1 && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (event.repeatCount == 0) increment()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (screen == 1 && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) return true
        return super.onKeyUp(keyCode, event)
    }
}
